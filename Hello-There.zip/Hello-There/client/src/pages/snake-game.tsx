import { useState, useEffect, useCallback, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Play, Pause, RotateCcw, Trophy, ArrowUp, ArrowDown, ArrowLeft, ArrowRight } from "lucide-react";

const GRID_SIZE = 20;
const CELL_SIZE = 20;
const INITIAL_SPEED = 150;

type Position = { x: number; y: number };
type Direction = "UP" | "DOWN" | "LEFT" | "RIGHT";

export default function SnakeGame() {
  const [snake, setSnake] = useState<Position[]>([{ x: 10, y: 10 }]);
  const [food, setFood] = useState<Position>({ x: 15, y: 15 });
  const [direction, setDirection] = useState<Direction>("RIGHT");
  const [isPlaying, setIsPlaying] = useState(false);
  const [gameOver, setGameOver] = useState(false);
  const [score, setScore] = useState(0);
  const [highScore, setHighScore] = useState(0);
  const directionRef = useRef(direction);

  const generateFood = useCallback((snakeBody: Position[]): Position => {
    let newFood: Position;
    do {
      newFood = {
        x: Math.floor(Math.random() * GRID_SIZE),
        y: Math.floor(Math.random() * GRID_SIZE),
      };
    } while (snakeBody.some(segment => segment.x === newFood.x && segment.y === newFood.y));
    return newFood;
  }, []);

  const resetGame = useCallback(() => {
    const initialSnake = [{ x: 10, y: 10 }];
    setSnake(initialSnake);
    setFood(generateFood(initialSnake));
    setDirection("RIGHT");
    directionRef.current = "RIGHT";
    setGameOver(false);
    setScore(0);
    setIsPlaying(false);
  }, [generateFood]);

  const moveSnake = useCallback(() => {
    if (!isPlaying || gameOver) return;

    setSnake(prevSnake => {
      const head = { ...prevSnake[0] };
      const currentDirection = directionRef.current;

      switch (currentDirection) {
        case "UP": head.y -= 1; break;
        case "DOWN": head.y += 1; break;
        case "LEFT": head.x -= 1; break;
        case "RIGHT": head.x += 1; break;
      }

      if (head.x < 0 || head.x >= GRID_SIZE || head.y < 0 || head.y >= GRID_SIZE) {
        setGameOver(true);
        setIsPlaying(false);
        return prevSnake;
      }

      if (prevSnake.some(segment => segment.x === head.x && segment.y === head.y)) {
        setGameOver(true);
        setIsPlaying(false);
        return prevSnake;
      }

      const newSnake = [head, ...prevSnake];

      if (head.x === food.x && head.y === food.y) {
        setScore(prev => {
          const newScore = prev + 10;
          setHighScore(current => Math.max(current, newScore));
          return newScore;
        });
        setFood(generateFood(newSnake));
      } else {
        newSnake.pop();
      }

      return newSnake;
    });
  }, [isPlaying, gameOver, food, generateFood]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight", " "].includes(e.key)) {
        e.preventDefault();
      }

      const currentDir = directionRef.current;

      switch (e.key) {
        case "ArrowUp":
          if (currentDir !== "DOWN") {
            setDirection("UP");
            directionRef.current = "UP";
          }
          break;
        case "ArrowDown":
          if (currentDir !== "UP") {
            setDirection("DOWN");
            directionRef.current = "DOWN";
          }
          break;
        case "ArrowLeft":
          if (currentDir !== "RIGHT") {
            setDirection("LEFT");
            directionRef.current = "LEFT";
          }
          break;
        case "ArrowRight":
          if (currentDir !== "LEFT") {
            setDirection("RIGHT");
            directionRef.current = "RIGHT";
          }
          break;
        case " ":
          if (!gameOver) {
            setIsPlaying(prev => !prev);
          }
          break;
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [gameOver]);

  useEffect(() => {
    const interval = setInterval(moveSnake, INITIAL_SPEED);
    return () => clearInterval(interval);
  }, [moveSnake]);

  const handleDirectionButton = (newDirection: Direction) => {
    const currentDir = directionRef.current;
    if (
      (newDirection === "UP" && currentDir !== "DOWN") ||
      (newDirection === "DOWN" && currentDir !== "UP") ||
      (newDirection === "LEFT" && currentDir !== "RIGHT") ||
      (newDirection === "RIGHT" && currentDir !== "LEFT")
    ) {
      setDirection(newDirection);
      directionRef.current = newDirection;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-primary/5 flex flex-col items-center justify-center p-4 gap-6" dir="rtl">
      <div className="text-center space-y-2">
        <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent" data-testid="game-title">
          🐍 لعبة الثعبان
        </h1>
        <p className="text-muted-foreground">استخدم الأسهم للتحكم أو الأزرار أدناه</p>
      </div>

      <div className="flex gap-6 items-start flex-wrap justify-center">
        <Card className="p-4 bg-card/80 backdrop-blur-sm border-2 border-primary/20 shadow-xl">
          <div className="flex justify-between items-center mb-4 gap-8">
            <div className="flex items-center gap-2">
              <Trophy className="w-5 h-5 text-yellow-500" />
              <span className="font-semibold text-lg" data-testid="high-score">{highScore}</span>
            </div>
            <div className="text-2xl font-bold text-primary" data-testid="current-score">
              النقاط: {score}
            </div>
          </div>

          <div
            className="relative rounded-lg overflow-hidden border-4 border-primary/30 shadow-inner"
            style={{
              width: GRID_SIZE * CELL_SIZE,
              height: GRID_SIZE * CELL_SIZE,
              background: "linear-gradient(135deg, hsl(var(--card)) 0%, hsl(var(--muted)) 100%)",
            }}
            data-testid="game-board"
          >
            <div
              className="absolute inset-0 opacity-10"
              style={{
                backgroundImage: `
                  linear-gradient(hsl(var(--border)) 1px, transparent 1px),
                  linear-gradient(90deg, hsl(var(--border)) 1px, transparent 1px)
                `,
                backgroundSize: `${CELL_SIZE}px ${CELL_SIZE}px`,
              }}
            />

            {snake.map((segment, index) => (
              <div
                key={index}
                className="absolute rounded-sm transition-all duration-75"
                style={{
                  left: segment.x * CELL_SIZE,
                  top: segment.y * CELL_SIZE,
                  width: CELL_SIZE - 2,
                  height: CELL_SIZE - 2,
                  margin: 1,
                  background: index === 0
                    ? "linear-gradient(135deg, hsl(var(--primary)) 0%, hsl(142 70% 35%) 100%)"
                    : `linear-gradient(135deg, hsl(142 70% ${55 - index * 2}%) 0%, hsl(142 60% ${45 - index * 2}%) 100%)`,
                  boxShadow: index === 0 ? "0 2px 8px rgba(0,0,0,0.3)" : "0 1px 4px rgba(0,0,0,0.2)",
                }}
                data-testid={index === 0 ? "snake-head" : `snake-segment-${index}`}
              />
            ))}

            <div
              className="absolute rounded-full animate-pulse"
              style={{
                left: food.x * CELL_SIZE,
                top: food.y * CELL_SIZE,
                width: CELL_SIZE - 2,
                height: CELL_SIZE - 2,
                margin: 1,
                background: "linear-gradient(135deg, hsl(0 72% 55%) 0%, hsl(0 72% 45%) 100%)",
                boxShadow: "0 0 12px hsl(0 72% 55% / 0.6)",
              }}
              data-testid="food"
            />

            {gameOver && (
              <div className="absolute inset-0 bg-background/80 backdrop-blur-sm flex flex-col items-center justify-center gap-4">
                <div className="text-3xl font-bold text-destructive">انتهت اللعبة!</div>
                <div className="text-xl">النقاط: {score}</div>
                <Button onClick={resetGame} className="gap-2" data-testid="restart-button">
                  <RotateCcw className="w-4 h-4" />
                  إعادة اللعب
                </Button>
              </div>
            )}
          </div>

          <div className="flex justify-center gap-3 mt-4">
            <Button
              variant={isPlaying ? "secondary" : "default"}
              size="lg"
              onClick={() => !gameOver && setIsPlaying(!isPlaying)}
              disabled={gameOver}
              className="gap-2 min-w-[120px]"
              data-testid="play-pause-button"
            >
              {isPlaying ? (
                <>
                  <Pause className="w-5 h-5" />
                  إيقاف
                </>
              ) : (
                <>
                  <Play className="w-5 h-5" />
                  ابدأ
                </>
              )}
            </Button>
            <Button
              variant="outline"
              size="lg"
              onClick={resetGame}
              className="gap-2"
              data-testid="reset-button"
            >
              <RotateCcw className="w-5 h-5" />
              إعادة
            </Button>
          </div>
        </Card>

        <Card className="p-4 bg-card/80 backdrop-blur-sm border border-border/50 md:hidden">
          <div className="grid grid-cols-3 gap-2 w-fit">
            <div />
            <Button
              variant="secondary"
              size="icon"
              className="w-14 h-14"
              onClick={() => handleDirectionButton("UP")}
              data-testid="button-up"
            >
              <ArrowUp className="w-6 h-6" />
            </Button>
            <div />
            <Button
              variant="secondary"
              size="icon"
              className="w-14 h-14"
              onClick={() => handleDirectionButton("LEFT")}
              data-testid="button-left"
            >
              <ArrowLeft className="w-6 h-6" />
            </Button>
            <Button
              variant="secondary"
              size="icon"
              className="w-14 h-14"
              onClick={() => handleDirectionButton("DOWN")}
              data-testid="button-down"
            >
              <ArrowDown className="w-6 h-6" />
            </Button>
            <Button
              variant="secondary"
              size="icon"
              className="w-14 h-14"
              onClick={() => handleDirectionButton("RIGHT")}
              data-testid="button-right"
            >
              <ArrowRight className="w-6 h-6" />
            </Button>
          </div>
        </Card>
      </div>

      <p className="text-sm text-muted-foreground text-center max-w-md">
        اضغط على <kbd className="px-2 py-1 bg-muted rounded text-xs font-mono">المسافة</kbd> للبدء/الإيقاف
        • استخدم <kbd className="px-2 py-1 bg-muted rounded text-xs font-mono">الأسهم</kbd> للتحكم
      </p>
    </div>
  );
}
